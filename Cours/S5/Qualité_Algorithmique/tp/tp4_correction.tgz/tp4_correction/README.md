Pour compiler en ligne de commande:

``` shell
javac --module-path /usr/lib/jvm/java-17-openjdk/lib/javafx.base.jar:/usr/lib/jvm/java-17-openjdk/lib/javafx.controls.jar:/usr/lib/jvm/java-17-openjdk/lib/javafx.graphics.jar --add-modules javafx.controls -d bin -cp bin -sourcepath src src/fr/iutlille/tp4/gui/*.java
```

Pour exécuter:

``` shell
java --module-path /usr/lib/jvm/java-17-openjdk/lib/javafx.base.jar:/usr/lib/jvm/java-17-openjdk/lib/javafx.controls.jar:/usr/lib/jvm/java-17-openjdk/lib/javafx.graphics.jar --add-modules javafx.controls -cp bin fr.iutlille.tp4.gui.AVLVisualiser
```

