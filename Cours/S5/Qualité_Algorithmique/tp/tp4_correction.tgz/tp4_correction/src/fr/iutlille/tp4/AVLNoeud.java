package fr.iutlille.tp4;

public class AVLNoeud implements AVL {
    private Integer valeur;
    private AVL fg;
    private AVL fd;
    private Integer hauteur;

    /* AVL feuille */

    public AVLNoeud(Integer v){
        this.valeur = v;
        this.hauteur = 0;
        this.fg = AVLVide.getInstance();
        this.fd = AVLVide.getInstance();
    }

    public AVLNoeud(Integer valeur, AVL fg, AVL fd) {
        this.valeur = valeur;
        this.fg = fg;
        this.fd = fd;
        this.hauteur = 1+Math.max(fg.getHauteur(),fd.getHauteur());
    }

    public Integer getValeur() {
        return valeur;
    }

    public AVL getGauche() {
        return fg;
    }

    public void setGauche(AVL fg) {
        this.fg = fg;
    }

    public AVL getDroite() {
        return fd;
    }

    public void setDroite(AVL fd) {
        this.fd = fd;
    }

    public Integer getHauteur() {
        return hauteur;
    }

    public void setHauteur(Integer hauteur) {
        this.hauteur = hauteur;
    }

    public boolean estVide(){
        return false;
    }

    public int deseq(){
        return fg.getHauteur()-fd.getHauteur();
    }

    @Override
    public boolean estAVL() {
        return fg.estAVL() && fd.estAVL() && (deseq() > -2) && (deseq() < 2);
    }

    public boolean cherche(Integer v){
            if (this.valeur == v) return true;
            if (v<this.valeur) return (!fg.estVide())?fg.cherche(v):false;
            else return (!fd.estVide())?fd.cherche(v):false;
    }

    public AVL rotation_droite(){
        AVL x = this.getGauche();
        if (!x.estVide()){
            AVL beta = x.getDroite();
            this.setGauche(beta);
            x.setDroite(this);
            this.setHauteur(1+Math.max(beta.getHauteur(),this.getDroite().getHauteur()));
            x.setHauteur(1+Math.max(x.getGauche().getHauteur(),this.getHauteur()));
            return x;
        } else return this;
    }

    public AVL rotation_gauche(){
        AVL y = this.getDroite();
        if (!y.estVide()){
            AVL beta = y.getGauche();
            this.setDroite(beta);
            y.setGauche(this);
            this.setHauteur(1+Math.max(beta.getHauteur(),this.getGauche().getHauteur()));
            y.setHauteur(1+Math.max(y.getDroite().getHauteur(),this.getHauteur()));
            return y;
        } else return this;
    }

    public AVL insere(Integer v){
        AVL result;
        if (v<this.getValeur()) {
            fg = fg.insere(v);
            if (deseq() == 2) {
                if (fg.deseq() == -1)
                    fg = fg.rotation_gauche();
                result = rotation_droite();
            } else result = this;
        } else {
            fd = fd.insere(v);
            if (deseq() == -2) {
                if (fd.deseq() == 1)
                    fd = fd.rotation_droite();
                result = rotation_gauche();
            } else result = this;
        }
        result.setHauteur(1+Math.max(result.getGauche().getHauteur(),result.getDroite().getHauteur()));
        return result;
    }
}